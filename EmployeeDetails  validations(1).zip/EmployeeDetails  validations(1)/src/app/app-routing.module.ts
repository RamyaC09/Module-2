import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule} from "@angular/common/http";
import {AppComponent} from './app.component';
import {EmployeeComponent} from './employee/employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
const routes: Routes = [
  {
    path:'EmployeeList',
    component:EmployeeListComponent
  },
  {
    path:'CreateEmployee',
    component:CreateEmployeeComponent
  },
  {
    path:' ',
    redirectTo:'/EmployeeList',
    pathMatch:'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
