import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../iemployee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
employees:IEmployee[];
  constructor(private employeeservice:EmployeeService) { }

  ngOnInit() {
    this.employees=this.employeeservice.getemployees();
  }
  deleteEmployee(emp)
  {
   let index=this.employees.indexOf(emp)
   this.employees.splice(index,1);

  }

}
